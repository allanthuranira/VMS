<!-- Vehicle Table (shown by default) -->
<div class="table" id="vehicleTable" style="display: block;">
    <?php include 'vehicleTable.php'; ?>
</div>

<!-- General Table -->
<div class="table" id="generalTable" style="display: none;">
    <?php include 'generalTable.php'; ?>
</div>

<!-- Staff Table -->
<div class="table" id="staffTable" style="display: none;">
    <?php include 'staffTable.php'; ?>
</div>

<!-- Participant Table -->
<div class="table" id="participantTable" style="display: none;">
    <?php include 'participantTable.php'; ?>
</div>

<!-- Visitor Table -->
<div class="table" id="visitorTable" style="display: none;">
    <?php include 'visitorTable.php'; ?>
</div>

<!-- KSG Vehicle Check-In Table -->
<div class="table" id="ksgVehicleCheckInTable" style="display: none;">
    <?php include 'ksgVehicleCheckInTable.php'; ?>
</div>
